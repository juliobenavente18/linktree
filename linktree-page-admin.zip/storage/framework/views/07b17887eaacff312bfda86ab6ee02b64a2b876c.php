

<?php $__env->startSection('title', 'Linktree'); ?>

<?php $__env->startSection('content_header'); ?>
<h1>Panel de Administración</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<p>Bienvenido <b><a target="_blank" href="admin/<?php echo e(Auth::user()->username); ?>"><?php echo e(Auth::user()->username); ?></a></b> al Panel de Administración de Linktree.</p>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="/css/admin_custom.css">
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/v/bs4/dt-1.11.4/b-2.2.2/b-html5-2.2.2/datatables.min.css" />

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script type="text/javascript" src="https://cdn.datatables.net/v/bs4/dt-1.11.4/b-2.2.2/b-html5-2.2.2/datatables.min.js"></script>

<script>
    $(document).ready(function() {
        $('#example').DataTable({
            "scrollX": true
        });
    });
    define(['pace'], function(pace) {
        pace.start({
            document: false
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\linktree-page-admin\resources\views/admin/index.blade.php ENDPATH**/ ?>