<?php $__env->startSection('title', 'Linktree'); ?>

<?php $__env->startSection('content_header'); ?>
<h1>Panel de Administración</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-12 card">
            <div class="card-body">
                <form action="<?php echo e(route('admin.links.store')); ?>" method="post">
                    <div class="row">
                        <div class="col-12 col-md-6">
                            <div class="form-group">
                                <label for="name">Nombre del Link</label>
                                <input type="text" id="name" name="name" class="form-control" placeholder="Ejm. Facebook">
                            </div>
                        </div>
                        <div class="col-12 col-md-6">
                            <div class="form-group">
                                <label for="name">Url</label>
                                <input type="text" id="link" name="link" class="form-control" placeholder="Ejm. https://youtube.com/user/aschmelyun">
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-12">
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="btn btn-primary">Guardar Link</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="/css/admin_custom.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script>
    console.log('Hi!');
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\linktree-page-admin\resources\views/admin/links/create.blade.php ENDPATH**/ ?>