<?php $__env->startSection('title', 'Linktree'); ?>

<?php $__env->startSection('content_header'); ?>
<h1>Panel de Administración</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-12 card">
            <div class="card-body">
                
                <table id="example" class="table table-striped" style="width: 100%;">
                    <thead>
                        <tr>
                            <th scope="col">Nombre</th>
                            <th scope="col">Url</th>
                            <th scope="col">Visits</th>
                            <th scope="col">Últimas visitas</th>
                            <th scope="col">Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $links; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($link->name); ?></td>
                            <td><a href="<?php echo e($link->link); ?>"><?php echo e($link->link); ?></a></td>
                            <td><?php echo e($link->visits_count); ?></td>
                            <td><?php echo e($link->latest_visit ? $link->latest_visit->created_at->format('M j Y - H:ia') : 'N/A'); ?></td>
                            <td><a class="btn btn-info font-weight-bolder" href="<?php echo e(route('admin.links.edit', $link->id)); ?>">Editar</a></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <a href="<?php echo e(route('admin.links.create')); ?>" class="btn btn-primary">Agregar Link</a>
                <a target="_blank" href="/admin/<?php echo e(Auth::user()->username); ?>" class="btn btn-warning">Ver LinkTree</a>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="/css/admin_custom.css">
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/v/bs4/dt-1.11.4/b-2.2.2/b-html5-2.2.2/datatables.min.css" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script type="text/javascript" src="https://cdn.datatables.net/v/bs4/dt-1.11.4/b-2.2.2/b-html5-2.2.2/datatables.min.js"></script>
<script>
    $(document).ready(function() {
        $("#example").DataTable({
            "scrollX": true,
            language: {
                "lengthMenu": "Mostrar _MENU_ registros",
                "zeroRecords": "No se encontraron resultados",
                "info": "Mostrando registros del _START_ al _END_ de un total de _TOTAL_ registros",
                "infoEmpty": "Mostrando registros del 0 al 0 de un total de 0 registros",
                "infoFiltered": "(filtrado de un total de _MAX_ registros)",
                "sSearch": "Buscar:",
                "oPaginate": {
                    "sFirst": "Primero",
                    "sLast": "Último",
                    "sNext": "Siguiente",
                    "sPrevious": "Anterior"
                },
                "sProcessing": "Procesando...",
            },
            dom: "lfrtip",
            
            
        });
    });
</script>
<!-- <script>
    $(document).ready(function() {
        $('#example').DataTable({
            "scrollX": true
        });
    });
    define(['pace'], function(pace) {
        pace.start({
            document: false
        });
    });
</script> -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\linktree-page-admin\resources\views/admin/links/index.blade.php ENDPATH**/ ?>