<?php $__env->startSection('title', 'Linktree'); ?>

<?php $__env->startSection('content_header'); ?>
<h1>Ajustes</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php $__env->startSection('plugins.BootstrapColorpicker', true); ?>
<div class="container">
    <div class="row">
        <div class="col-12 card">
            <div class="card-body">
                <div>
                    <p class="text-info">Los cambios que realices se verán reflejados en tu página de LinkTree</p>
                </div>

                <form action="/admin/settings" method="post">
                    <div class="row">
                        <div class="col-12 col-md-6">
                            <div class="form-group">
                                <label for="background_color">Color de Fondo Linktree</label>
                                
                                <?php if (isset($component)) { $__componentOriginale85120d9648911b64117bfc5ebfc6117ec22745d = $component; } ?>
<?php $component = $__env->getContainer()->make(JeroenNoten\LaravelAdminLte\Components\Form\InputColor::class, ['id' => 'background_color','name' => 'background_color']); ?>
<?php $component->withName('adminlte-input-color'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['autocomplete' => 'off','class' => 'form-control'.e($errors->first('background_color') ? ' is-invalid' : '').'','value' => ''.e($user->background_color).'','placeholder' => 'Seleccione color de fondo...']); ?>
                                     <?php $__env->slot('prependSlot', null, []); ?> 
                                        <div class="input-group-text bg-gradient-light">
                                            <i class="fas fa-lg fa-tint"></i>
                                        </div>
                                     <?php $__env->endSlot(); ?>
                                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale85120d9648911b64117bfc5ebfc6117ec22745d)): ?>
<?php $component = $__componentOriginale85120d9648911b64117bfc5ebfc6117ec22745d; ?>
<?php unset($__componentOriginale85120d9648911b64117bfc5ebfc6117ec22745d); ?>
<?php endif; ?>
                                

                                <?php if($errors->first('background_color')): ?>
                                <div class="invalid-feedback"><?php echo e($errors->first('background_color')); ?></div>

                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="col-12 col-md-6">
                            <div class="form-group">
                                <label for="text_color">Color de Texto LinkTree</label>
                                <?php if (isset($component)) { $__componentOriginale85120d9648911b64117bfc5ebfc6117ec22745d = $component; } ?>
<?php $component = $__env->getContainer()->make(JeroenNoten\LaravelAdminLte\Components\Form\InputColor::class, ['id' => 'text_color','name' => 'text_color']); ?>
<?php $component->withName('adminlte-input-color'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['autocomplete' => 'off','class' => 'form-control'.e($errors->first('text_color') ? ' is-invalid' : '').'','value' => ''.e($user->text_color).'','placeholder' => 'Seleccione color de texto...']); ?>
                                     <?php $__env->slot('prependSlot', null, []); ?> 
                                        <div class="input-group-text bg-gradient-light">
                                            <i class="fas fa-lg fa-tint"></i>
                                        </div>
                                     <?php $__env->endSlot(); ?>
                                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale85120d9648911b64117bfc5ebfc6117ec22745d)): ?>
<?php $component = $__componentOriginale85120d9648911b64117bfc5ebfc6117ec22745d; ?>
<?php unset($__componentOriginale85120d9648911b64117bfc5ebfc6117ec22745d); ?>
<?php endif; ?>
                                
                                <?php if($errors->first('text_color')): ?>
                                <div class="invalid-feedback"><?php echo e($errors->first('text_color')); ?></div>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="col-12 col-md-6">
                            <div class="form-group">
                                <label for="title_color">Color de Titulo LinkTree</label>
                                <?php if (isset($component)) { $__componentOriginale85120d9648911b64117bfc5ebfc6117ec22745d = $component; } ?>
<?php $component = $__env->getContainer()->make(JeroenNoten\LaravelAdminLte\Components\Form\InputColor::class, ['id' => 'title_color','name' => 'title_color']); ?>
<?php $component->withName('adminlte-input-color'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['autocomplete' => 'off','class' => 'form-control'.e($errors->first('title_color') ? ' is-invalid' : '').'','value' => ''.e($user->title_color).'','placeholder' => 'Seleccione color de Título...']); ?>
                                     <?php $__env->slot('prependSlot', null, []); ?> 
                                        <div class="input-group-text bg-gradient-light">
                                            <i class="fas fa-lg fa-tint"></i>
                                        </div>
                                     <?php $__env->endSlot(); ?>
                                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale85120d9648911b64117bfc5ebfc6117ec22745d)): ?>
<?php $component = $__componentOriginale85120d9648911b64117bfc5ebfc6117ec22745d; ?>
<?php unset($__componentOriginale85120d9648911b64117bfc5ebfc6117ec22745d); ?>
<?php endif; ?>
                                
                                <?php if($errors->first('title_color')): ?>
                                <div class="invalid-feedback"><?php echo e($errors->first('title_color')); ?></div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-12">
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="btn btn-primary<?php echo e(session('success') ? ' is-valid' : ''); ?>">Guardar Cambios</button>
                            <?php if(session('success')): ?>
                            <div class="valid-feedback"><?php echo e(session('success')); ?></div>
                            <?php endif; ?>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\linktree-page-admin\resources\views/admin/users/edit.blade.php ENDPATH**/ ?>