


<?php $__env->startSection('content'); ?>
<?php if(session('info')): ?>
<div class="alert alert-success">
    <strong><?php echo e(session('info')); ?></strong>
</div>
<?php endif; ?>
<div class="container">
    <h1>ASIGNAR ROL</h1>
    <br>
    <div class="card-body">
        <div class="mb-3">
            <label for="name" class="form-label">Username</label>
            <input type="text" name="username" id="username" class="form-control" value="<?php echo e($user->username); ?>" readonly>
        </div>
        <div class="mb-3">
            <label for="email" class="form-label">Email</label>
            <input type="email" name="email" id="email" class="form-control" value="<?php echo e($user->email); ?>" readonly>
        </div>

        <form action="<?php echo e(route('admin.users_linktree.update', $user)); ?>" method="post">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <h2 class="title">Asignar Rol</h2>
            <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rol): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="form-check mt-3 mb-3">
                <input class="form-check-input" type="checkbox" name="roles[]" value="<?php echo e($rol->id); ?>">
                <label class="form-check-label" for="role1">
                    <?php echo e($rol['name']); ?>

                </label>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


            <a href="<?php echo e(route('admin.users_linktree.index')); ?>" class="btn btn-danger" tabindex="5">Cancelar</a>

            <button type="submit" class="btn btn-primary" tabindex="6">Guardar</button>


        </form>
    </div>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\linktree-page-admin\resources\views/admin/users_linktree/edit.blade.php ENDPATH**/ ?>